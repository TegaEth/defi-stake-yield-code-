from scripts.deploy import update_front_end


def main():
    update_front_end()


if __name__ == "__main__":
    main()
