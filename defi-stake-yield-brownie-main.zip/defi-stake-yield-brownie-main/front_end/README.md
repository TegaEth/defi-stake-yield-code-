created with `create-react-app front_end --template typescript`

To run:
```
cd front_end
yarn
yarn start
```
